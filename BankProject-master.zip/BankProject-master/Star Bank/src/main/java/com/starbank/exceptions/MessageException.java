package com.starbank.exceptions;

public class MessageException extends Exception {

	private static final long serialVersionUID = -8605174555258163392L;

	public MessageException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MessageException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public MessageException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public MessageException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
