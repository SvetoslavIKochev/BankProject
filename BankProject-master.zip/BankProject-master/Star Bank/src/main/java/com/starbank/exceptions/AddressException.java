package com.starbank.exceptions;

public class AddressException extends Exception {

	private static final long serialVersionUID = -8550329051670443820L;

	public AddressException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AddressException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AddressException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public AddressException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
