package com.starbank.exceptions;

public class InterestException extends Exception {

	private static final long serialVersionUID = -3431819931268258831L;

	public InterestException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InterestException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public InterestException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public InterestException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public InterestException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
}
