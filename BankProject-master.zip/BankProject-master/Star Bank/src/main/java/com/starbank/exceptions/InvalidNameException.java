package com.starbank.exceptions;

public class InvalidNameException extends Exception {

	private static final long serialVersionUID = 2597229224146510611L;

	public InvalidNameException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidNameException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public InvalidNameException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public InvalidNameException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
