package com.starbank.exceptions;

public class InvalidEgnException extends Exception {

	private static final long serialVersionUID = 5557446551367567974L;

	public InvalidEgnException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidEgnException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public InvalidEgnException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public InvalidEgnException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
