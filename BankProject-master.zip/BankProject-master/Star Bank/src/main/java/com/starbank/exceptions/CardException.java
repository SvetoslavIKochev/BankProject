package com.starbank.exceptions;

public class CardException extends Exception {

	private static final long serialVersionUID = 6596624069699802371L;

	public CardException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CardException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public CardException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public CardException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
