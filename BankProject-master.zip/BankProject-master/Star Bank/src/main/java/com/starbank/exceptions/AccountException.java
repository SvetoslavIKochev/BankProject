package com.starbank.exceptions;

public class AccountException extends Exception {

	private static final long serialVersionUID = 1504428482034787567L;

	public AccountException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AccountException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public AccountException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public AccountException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
