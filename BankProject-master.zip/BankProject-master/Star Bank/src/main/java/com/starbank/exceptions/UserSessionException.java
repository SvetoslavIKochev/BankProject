package com.starbank.exceptions;

public class UserSessionException extends Exception {

	private static final long serialVersionUID = 5011018683583080760L;

	public UserSessionException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserSessionException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public UserSessionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UserSessionException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
