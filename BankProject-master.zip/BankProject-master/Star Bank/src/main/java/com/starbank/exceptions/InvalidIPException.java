package com.starbank.exceptions;

public class InvalidIPException extends Exception {

	private static final long serialVersionUID = 5065137343873947558L;

	public InvalidIPException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidIPException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidIPException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidIPException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
