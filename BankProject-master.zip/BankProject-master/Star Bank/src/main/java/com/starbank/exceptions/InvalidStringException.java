package com.starbank.exceptions;

public class InvalidStringException extends Exception {

	private static final long serialVersionUID = 6832260207788812402L;

	public InvalidStringException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidStringException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidStringException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidStringException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
