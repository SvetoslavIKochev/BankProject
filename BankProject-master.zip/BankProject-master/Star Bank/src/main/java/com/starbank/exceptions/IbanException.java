package com.starbank.exceptions;

public class IbanException extends Exception {

	private static final long serialVersionUID = -8032088926862970634L;

	public IbanException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IbanException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public IbanException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public IbanException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
