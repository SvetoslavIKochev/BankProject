package com.starbank.exceptions;

public class DateTimeException extends Exception {

	private static final long serialVersionUID = 3424209185907515757L;

	public DateTimeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DateTimeException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public DateTimeException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public DateTimeException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
