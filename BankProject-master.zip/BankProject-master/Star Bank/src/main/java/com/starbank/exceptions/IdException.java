package com.starbank.exceptions;

public class IdException extends Exception {

	private static final long serialVersionUID = -8594396523298559095L;

	public IdException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IdException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public IdException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public IdException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
