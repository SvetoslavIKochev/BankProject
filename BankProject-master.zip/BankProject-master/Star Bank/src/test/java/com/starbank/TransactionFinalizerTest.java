package com.starbank;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.starbank.model.dao.repo.TransactionFinalizerRepository;

public class TransactionFinalizerTest {
	
//	@Test
//	public void testFinalizeAllUserTransactions() {
//		assertTrue(new TransactionFinalizerRepository().finalizeAllUserTransactions());
//	}
}
